function [Next_all]  = EnvSelection(PopObj,Next_comb,K)

%% Population selection
[N,~]        = size(Next_comb);
Prob         = sum(Next_comb,2);
Pmax         = max(Prob);


Next_all = false(1,N);
ind = 1;
for jj = Pmax : -1 : 0
    XX            = find(Prob == jj);
    FrontNo(XX)   = ind;
    ind           = ind+1;
end

MaxFNo         = find(cumsum(hist(FrontNo,1:max(FrontNo)))>=K,1);

Best           = find(FrontNo<MaxFNo);

Least          = find(FrontNo==MaxFNo);

x              = [Best, Least];
y              = sort(x);

y              = Select_sol(PopObj(y,:),y,FrontNo(y),K);

Next_all(y)    = true;
end

