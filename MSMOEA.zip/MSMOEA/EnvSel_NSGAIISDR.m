function [Next_all,Front_all,CrowdDis_all] = EnvSel_NSGAIISDR(Population,FunctionValue,N,zmin,zmax)
% The environmental selection of NSGA-II

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

%% Normalization

PopObj = FunctionValue - repmat(zmin,length(FunctionValue),1);
NN     = size(PopObj,1);
range  = zmax - zmin;
if 0.05*max(range) < min(range)
    PopObj = PopObj./repmat(range,length(Population),1);
end
[~,x]      = unique(round(PopObj*1e6)/1e6,'rows');
x          = sort(x);
PopObj     = PopObj(x,:);
Population = Population(x);
N          = min(N,length(Population));

%% Non-dominated sorting
[FrontNo,MaxFNo] = NDSort_SDR(PopObj,N);
Next = FrontNo < MaxFNo;

%% Calculate the crowding distance of each solution
CrowdDis = CrowdingDistance(PopObj,FrontNo);

%% Select the solutions in the last front based on their crowding distances
Last     = find(FrontNo==MaxFNo);
[~,Rank] = sort(CrowdDis(Last),'descend');
Next(Last(Rank(1:N-sum(Next)))) = true;

xx           = x(Next);
Next_all     = false(1,NN);
Next_all(xx) = true;


Front_all        = zeros(1,NN);
Front_all(x)     = FrontNo;
yy               = find(FrontNo ==0);
Front_all(yy)    = inf;

CrowdDis_all     = zeros(1,NN);
CrowdDis_all(x)  = CrowdDis ;
zz               = find(CrowdDis_all ==0);
CrowdDis_all(zz) = 0;

%% Population for next generation

end