function x  = Select_sol(PopObj,x,FrontNo,K)

[N,M]              = size(PopObj);
Next               = false(1,N);

[~,extreme]        = min(pdist2(PopObj,eye(M),'cosine'),[],1);
Next(extreme)      = true;
MM                 = max(FrontNo);
FrontNo(extreme)   = MM+3;

MaxFNo             = find(cumsum(hist(FrontNo,1:max(FrontNo)))>=K-sum(Next),1);
Sel                = FrontNo<MaxFNo;
Next(Sel)          = true;

Last               = find(FrontNo==MaxFNo);

if sum(Next) == K
    Choose             = [];
elseif sum(Next) < K
    Choose             = EnvSel_Kmeans(PopObj(Last,:),K-sum(Next));
end

if sum(Next) > K
    keyboard
end

if ~isempty(Choose)
    Sel_next           = Last(Choose);
    Next(Sel_next)     = true;
end

x                  = x(Next);

end