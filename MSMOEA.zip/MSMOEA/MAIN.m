% The code of MSEMOEA
clc;format compact;tic;
%-----------------------------------------------------------------------------------------
% Parameters setting
for Problem = 1 : 7 % test problem
    
    for M = [5 8 10 15 20]  % number of objectives
        
        if Problem == 1 % DTLZ1
            K = 5;  % the parameter in DTLZ1
        elseif Problem == 2 || 3 || 4
            K = 10;  % the parameter in DTLZ2, DTLZ3, DTLZ4,
        elseif Problem == 5 || 6
            K = 10;  % the parameter in DTLZ5, DTLZ6
        elseif Problem == 7 % DTLZ7
            K = 20;  % the parameter in DTLZ7
        end
        
        %% Number of Generations
        if Problem == 1
            if M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 550;
            elseif M == 20
                Generations = 600;
            end
        end
        
        if Problem == 2
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 3
            if M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 550;
            elseif M == 20
                Generations = 600;
            end
        end
        
        if Problem == 4
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 5
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 6
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 7
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        %% Population size
        if M == 2
            N = 100;            % population size
        elseif M == 3
            N = 120;
        elseif M == 5
            N = 126;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 275;
        elseif M == 15
            N = 240;
        elseif M == 20
            N = 230;
        end
        
        D = M + K - 1;
        
        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        Boundary   = [MaxValue;MinValue];
        Runs       =  30; 
        %%-------------------------------------------------------------------------------------------------------------------------------
        for run = 1 : Runs
            v  = 2;
            % Initialization
            [W,N]                 = UniformPoint(N,M);
            Population            = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue         = F_DTLZ(Population,Problem,M, K);	% calculate the objective values
            [FrontValue,MaxFront] = ENS(FunctionValue,'all');               % non-dominated sort using A-ENS
            
            %% Initialization
            % NSGAII-SDR
            zmin                       = min(FunctionValue,[],1);
            zmax                       = max(FunctionValue,[],1);
            [~,Front_SDR,Crowd_SDR]    = EnvSel_NSGAIISDR(Population,FunctionValue,N,zmin,zmax);
            
            % ISDEPlus
            Dist_ISDEPlus             = F_ISDEplus(FunctionValue);
            
            % EFR-RR
            z                         = min(FunctionValue,[],1);
            znad                      = max(FunctionValue,[],1);
            
            % RPD_NSGAII
            [~,FrontNo_RPD,d2]        =  EnvSel_RPD_NSGAII(FunctionValue,W,N);
            
            %% initial population
            Wt        = [0.25 0.25 0.25 0.25];
            N_ratio   = [0.25 0.25 0.25 0.25];
            VV        = ceil(N*0.25);
            N_sel     = [VV VV VV VV];
            
            if sum(N_sel,2) < N
                for i   = 1 : N-sum(N_sel,2)
                    ind  = randi(length(N_sel));
                    indx = N_sel(ind);
                    indx = indx+1;
                    N_sel(ind) = indx;
                end
            else
                for i   = 1 : sum(N_sel,2)- N
                    ind  = randi(length(N_sel));
                    indx = N_sel(ind);
                    indx = indx-1;
                    N_sel(ind) = indx;
                end
            end
            
            VC1   = [];
            VC2   = [];
            %%-----------------------------------------------------------------------------------------
            % Main iterations
            for Gene = 1 : Generations
                %% Mating selection
                % Mating Selection using NSGAII-SDR
                Mating_NSGAIISDR    = TournamentSelection(2,N,Front_SDR,-Crowd_SDR);
                
                % Mating Selection using ISDE+
                Mating_ISDEplus     = TournamentSelection(2,N,Dist_ISDEPlus);
                
                % Mating Selection using EFR-RR
                [PopObj,z,znad]     = Normalization(FunctionValue,z,znad);
                RgFrontNO           = MaximumRanking(PopObj,W,v);
                Mating_EFR_RR       = TournamentSelection(2,N,RgFrontNO);
                
                % Mating Selection using RPD_NSGAII
                Mating_RPD_NSGAII    = TournamentSelection(2,N,FrontNo_RPD,d2);
                %% Offspring Generation
                N1                    = N_sel(1);
                N2                    = N_sel(2);
                N3                    = N_sel(3);
                N4                    = N_sel(4);
                
                M1                    = Mating_NSGAIISDR(1:N1);
                M2                    = Mating_ISDEplus(1:N2);
                M3                    = Mating_EFR_RR(1:N3);
                M4                    = Mating_RPD_NSGAII(1:N4);
                
                Off1                  = GA(Population(M1,:),{1,20,1,20},MinValue,MaxValue);
                Off2                  = GA(Population(M2,:),{1,20,1,20},MinValue,MaxValue);
                Off3                  = GA(Population(M3,:),{1,20,1,20},MinValue,MaxValue);
                Off4                  = GA(Population(M4,:),{1,20,1,20},MinValue,MaxValue);
                
                N1_off                = size(Off1,1);
                N2_off                = size(Off2,1);
                N3_off                = size(Off3,1);
                N4_off                = size(Off4,1);
                %% AGE-MOEA
                if  N1_off > N1
                    rem_sol1         = randi(N1,[1,1]);
                    Off1(rem_sol1,:)  = [];
                elseif N1_off < N1
                    req_sol1         = randi(N1,[2,1]);
                    r_sol1           = GAhalf(Population(req_sol1,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off1             = [Off1;r_sol1];
                end
                
                %% ISDEplus
                if  N2_off > N2
                    rem_sol2         = randi(N2,[1,1]);
                    Off2(rem_sol2,:)  = [];
                elseif N2_off < N2
                    req_sol2         = randi(N2,[2,1]);
                    r_sol2           = GAhalf(Population(req_sol2,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off2             = [Off2;r_sol2];
                end
                
                %% EFR-RR
                if  N3_off > N3
                    rem_sol3         = randi(N3,[1,1]);
                    Off3(rem_sol3,:)  = [];
                elseif N3_off < N3
                    req_sol3         = randi(N3,[2,1]);
                    r_sol3           = GAhalf(Population(req_sol3,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off3             = [Off3;r_sol3];
                end
                
                %% RPD-NSGAII
                if  N4_off > N4
                    rem_sol4         = randi(N4,[1,1]);
                    Off4(rem_sol4,:)  = [];
                elseif N4_off < N4
                    req_sol4         = randi(N4,[2,1]);
                    r_sol4           = GAhalf(Population(req_sol4,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off4             = [Off4;r_sol4];
                end
                
                Offspring             = [Off1;Off2;Off3;Off4];
                NewF                  = F_DTLZ(Offspring,Problem,M, K);    % calculate the objective values
                
                %% Prerequirements
                % NSGAII-SDR
                zmin                    = min([zmin;NewF],[],1);
                zmax                    = max([zmax;FunctionValue(Front_SDR==1,:)],[],1);
                
                %% Combining Populations
                Population            = [Population;Offspring];
                FunctionValue         = [FunctionValue;NewF];
                %% Distance calculation for ISDEplus
                Dist_ISDEPlus            = F_ISDEplus(FunctionValue);
                %% environmental selection
                % environmental selection using NSGAII-SDR
                [Next_NSGAIISDR,Front_SDR,Crowd_SDR]  = EnvSel_NSGAIISDR(Population,FunctionValue,N,zmin,zmax);
                
                % environmental selection using ISDE+
                Dist_ISDEPlus                         = F_ISDEplus(FunctionValue);
                Next_ISDEplus                         = EnvSel_ISDEplus(Dist_ISDEPlus,N);
                
                % environmental selection using 1by1EA
                [Next_EFR_RR,RgFrontNo,z,znad]                  = EnvSel_EFF_RR(FunctionValue,W,N,v,z,znad);
                
                
                % environmental selection using RPD_NSGAII
                [Next_RPD_NSGAII,FrontNo_RPD,d2]     = EnvSel_RPD_NSGAII(FunctionValue,W,N);
                
                %% Environmental Selection of multi-algorithm
                Next_comb                = [Next_NSGAIISDR',Next_ISDEplus',Next_EFR_RR,Next_RPD_NSGAII'];
                Next_all                 = EnvSelection(FunctionValue,Next_comb,N);
                [N_ratio,Wt,N_sel]       = adaboost_adap(Next_all,N_ratio,N_sel,Wt,N);
                
                %% population for next generation
                Population      = Population(Next_all,:);      % solutions on decision space
                FunctionValue   = FunctionValue(Next_all,:);
                
                % Next AGE-MOEA
                Front_SDR     = Front_SDR(Next_all);
                Crowd_SDR       = Crowd_SDR(Next_all);
                
                % NextISDEplus
                Dist_ISDEPlus   = Dist_ISDEPlus(Next_all);
                
                % Next 1by1EA
                RgFrontNo        = RgFrontNo(Next_all);
                
                % Next RPD-NSGAII
                FrontNo_RPD      = FrontNo_RPD(Next_all);
                d2               = d2(Next_all);
                Gene
            end
            F_output(Population,toc,'MSMOEA',Problem,M,K,run);
        end
    end
    clear all;clc
end
